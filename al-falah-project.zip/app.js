/* ============================================================
   AL FALAH ISLAMIC ONLINE INSTITUTE — FRONT-END PROTOTYPE
   All data is mocked and stored in this browser's localStorage
   (per-viewer only). No real backend, auth, or file storage.
   ============================================================ */

const DEFAULT_LOGO = "assets/logo.jpg";
const FOUNDER_PHOTO = "assets/founder.jpg";
const svgIcons = {
  quran:'<svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20M4 4.5A2.5 2.5 0 016.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15z"/></svg>',
  book:'<svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20M4 4.5A2.5 2.5 0 016.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15z"/></svg>',
  star:'<svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M12 2l2.6 6.6L22 9l-5.5 4.6L18 22l-6-4-6 4 1.5-8.4L2 9l7.4-.4z"/></svg>',
  pray:'<svg viewBox="0 0 24 24" fill="none" stroke-width="2"><circle cx="12" cy="5" r="2"/><path d="M12 7v6M8 13l4-2 4 2M6 21l6-8 6 8"/></svg>',
  mic:'<svg viewBox="0 0 24 24" fill="none" stroke-width="2"><rect x="9" y="2" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0014 0M12 18v4"/></svg>',
};
const DEFAULT_STATE = {
  logo: DEFAULT_LOGO,
  hadith: {ar:"طَلَبُ الْعِلْمِ فَرِيضَةٌ عَلَى كُلِّ مُسْلِمٍ", tr:"Seeking knowledge is an obligation upon every Muslim.", src:"Sunan Ibn Majah"},
  courses: [
    {id:1, title:"Noorani Qaida", teacher:"Qari Bilal Ahmed", desc:"Foundational course for correct Arabic letter recognition and pronunciation.", duration:"3 months", timing:"Mon–Fri, 5:00 PM", students:42, progress:65, icon:"book"},
    {id:2, title:"Quran Reading", teacher:"Qari Bilal Ahmed", desc:"Fluent Quran reading with proper makharij.", duration:"6 months", timing:"Mon–Fri, 6:00 PM", students:38, progress:40, icon:"quran"},
    {id:3, title:"Quran Tajweed", teacher:"Hafiza Sumaira", desc:"Detailed rules of Tajweed for precise recitation.", duration:"8 months", timing:"Tue/Thu, 7:00 PM", students:29, progress:20, icon:"quran"},
    {id:4, title:"Hifz-ul-Quran", teacher:"Hafiz Usman Tariq", desc:"Complete Quran memorization program with revision plan.", duration:"Ongoing", timing:"Daily, 4:00 PM", students:17, progress:12, icon:"quran"},
    {id:5, title:"Duas & Salah", teacher:"Ustadha Ayesha", desc:"Essential daily duas and correct method of Salah.", duration:"2 months", timing:"Sat/Sun, 3:00 PM", students:51, progress:80, icon:"pray"},
    {id:6, title:"Basic Islamic Knowledge", teacher:"Ustadh Imran", desc:"Fundamentals of Islamic beliefs and practices.", duration:"3 months", timing:"Mon/Wed, 5:30 PM", students:33, progress:55, icon:"book"},
    {id:7, title:"Aqaaid", teacher:"Mufti Zubair", desc:"Core Islamic creed and beliefs explained simply.", duration:"3 months", timing:"Wed, 6:30 PM", students:22, progress:0, icon:"star"},
    {id:8, title:"Islamic Adab & Akhlaaq", teacher:"Ustadha Ayesha", desc:"Manners and character building rooted in Sunnah.", duration:"2 months", timing:"Fri, 5:00 PM", students:40, progress:30, icon:"star"},
    {id:9, title:"Stories of the Prophets", teacher:"Ustadh Imran", desc:"Life lessons from the Prophets (peace be upon them).", duration:"4 months", timing:"Sat, 4:00 PM", students:47, progress:10, icon:"book"},
    {id:10, title:"Naat", teacher:"Qari Bilal Ahmed", desc:"Learn beautiful Naats with correct tarannum.", duration:"2 months", timing:"Sun, 3:00 PM", students:19, progress:0, icon:"mic"},
  ],
  classes: [
    {id:1, course:"Hifz-ul-Quran", teacher:"Hafiz Usman Tariq", date:"Today", time:"4:00 PM", status:"live", link:"https://meet.google.com/demo-link"},
    {id:2, course:"Quran Tajweed", teacher:"Hafiza Sumaira", date:"Today", time:"7:00 PM", status:"upcoming", link:"https://zoom.us/j/demo"},
    {id:3, course:"Noorani Qaida", teacher:"Qari Bilal Ahmed", date:"Tomorrow", time:"5:00 PM", status:"upcoming", link:"https://meet.google.com/demo-link-2"},
    {id:4, course:"Duas & Salah", teacher:"Ustadha Ayesha", date:"Sat", time:"3:00 PM", status:"upcoming", link:"https://zoom.us/j/demo2"},
  ],
  videos: [
    {id:1, title:"Makharij al-Huroof Explained", teacher:"Qari Bilal Ahmed", desc:"Correct articulation points of Arabic letters.", duration:"12:40"},
    {id:2, title:"Surah Al-Fatiha — Tajweed Breakdown", teacher:"Hafiza Sumaira", desc:"Line-by-line Tajweed rules applied.", duration:"18:05"},
    {id:3, title:"How to Pray Salah Correctly", teacher:"Ustadha Ayesha", desc:"Step by step guide for beginners.", duration:"9:22"},
    {id:4, title:"Story of Prophet Yusuf (AS) — Part 1", teacher:"Ustadh Imran", desc:"Lessons in patience and trust in Allah.", duration:"22:15"},
  ],
  materials: [
    {id:1, title:"Noorani Qaida — Lesson 1 PDF", course:"Noorani Qaida", type:"PDF", uploader:{name:"Admin", role:"admin", email:"admin"}, fileData:null},
    {id:2, title:"Tajweed Rules Summary Notes", course:"Quran Tajweed", type:"Notes", uploader:{name:"Admin", role:"admin", email:"admin"}, fileData:null},
    {id:3, title:"40 Daily Duas Booklet", course:"Duas & Salah", type:"PDF", uploader:{name:"Admin", role:"admin", email:"admin"}, fileData:null},
    {id:4, title:"Names of Allah — Illustrated", course:"Basic Islamic Knowledge", type:"Photo", uploader:{name:"Admin", role:"admin", email:"admin"}, fileData:null},
  ],
  assignments: [
    {id:1, title:"Tajweed Rule Worksheet 3", course:"Quran Tajweed", due:"Sep 22", status:"pending"},
    {id:2, title:"Memorize Surah Al-Mulk (1-10)", course:"Hifz-ul-Quran", due:"Sep 24", status:"submitted"},
    {id:3, title:"Write 10 Daily Duas", course:"Duas & Salah", due:"Sep 18", status:"reviewed", feedback:"Excellent work, well written!"},
  ],
  students: [
    {id:1, name:"Ahmed Khan", email:"ahmed@example.com", city:"Karachi", status:"approved"},
    {id:2, name:"Fatima Noor", email:"fatima@example.com", city:"Lahore", status:"pending"},
    {id:3, name:"Bilal Hussain", email:"bilal@example.com", city:"Islamabad", status:"approved"},
    {id:4, name:"Zainab Ali", email:"zainab@example.com", city:"Multan", status:"blocked"},
  ],
  teachers: [
    {id:1, name:"Qari Bilal Ahmed", subject:"Quran Reading & Naat", status:"active"},
    {id:2, name:"Hafiza Sumaira", subject:"Tajweed", status:"active"},
    {id:3, name:"Hafiz Usman Tariq", subject:"Hifz-ul-Quran", status:"active"},
  ],
  islamicUpdates: [
    {id:1, title:"Ramadan Kareem Wallpaper", category:"Wallpaper", thumb:null, link:""},
    {id:2, title:"Jumma Mubarak Status", category:"Status", thumb:null, link:""},
    {id:3, title:"Surah Al-Fajr Recitation Reel", category:"Reel", thumb:null, link:""},
    {id:4, title:"Al Falah Announcement Poster", category:"Poster", thumb:null, link:""},
    {id:5, title:"Adhan Ringtone — Makkah", category:"Ringtone", thumb:null, link:""},
    {id:6, title:"99 Names of Allah Wallpaper", category:"Wallpaper", thumb:null, link:""},
  ],
  banner: {image:null, caption:""},
};

let state = loadState();
let currentUser = {name:"Ahmed Khan", email:"ahmed@example.com", role:"student"};
let demoRole = "student";
applyLogo();
applyBanner();

function loadState(){
  try{
    const raw = localStorage.getItem('alfalah_state');
    if(raw){
      const parsed = JSON.parse(raw);
      if(!parsed.logo) parsed.logo = DEFAULT_LOGO;
      if(!parsed.islamicUpdates) parsed.islamicUpdates = JSON.parse(JSON.stringify(DEFAULT_STATE.islamicUpdates));
      if(!parsed.banner) parsed.banner = {image:null, caption:""};
      return parsed;
    }
  }catch(e){ console.warn('storage read failed', e); }
  return JSON.parse(JSON.stringify(DEFAULT_STATE));
}
function applyLogo(){
  document.querySelectorAll('.app-logo-img').forEach(img=>{ img.src = state.logo; });
  const fp = document.getElementById('founderPhotoImg');
  if(fp) fp.src = FOUNDER_PHOTO;
}
let bannerDismissed = false;
function applyBanner(){
  ['student','admin','teacher'].forEach(key=>{
    const el = document.getElementById('homeBanner-'+key);
    if(!el) return;
    if(!state.banner || !state.banner.image || bannerDismissed){
      el.style.display = 'none';
      el.innerHTML = '';
      return;
    }
    el.style.display = 'block';
    el.innerHTML = `
      <span class="badge">📢 ANNOUNCEMENT</span>
      <button class="close" onclick="dismissBanner()"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
      <img src="${state.banner.image}" alt="Institute announcement poster">
      ${state.banner.caption ? `<div class="caption">${state.banner.caption}</div>` : ''}
    `;
  });
}
function dismissBanner(){ bannerDismissed = true; applyBanner(); }
function changeBannerSheet(){
  openSheet(`<h3>Home Poster / Announcement</h3>
    <p style="font-size:11.5px; color:var(--charcoal-400); margin-top:-8px;">Upload a reel/story-sized poster (vertical, e.g. 1080×1920). It appears on the Home screen for every Student, Teacher and Admin.</p>
    <div class="field"><label>Poster Image</label><input type="file" id="bannerFile" accept="image/*"></div>
    <div class="field"><label>Caption (optional)</label><input type="text" id="bannerCaption" placeholder="e.g. Eid holidays announcement"></div>
    <button class="btn" onclick="saveBanner()">Publish to Home</button>
    ${state.banner && state.banner.image ? `<button class="btn ghost" style="margin-top:10px;" onclick="removeBanner()">Remove Current Poster</button>` : ''}`);
}
function saveBanner(){
  const fileInput = document.getElementById('bannerFile');
  const file = fileInput && fileInput.files[0];
  const caption = document.getElementById('bannerCaption').value.trim();
  if(!file){ showToast('Choose a poster image first'); return; }
  const reader = new FileReader();
  reader.onload = (e)=>{
    state.banner = {image:e.target.result, caption};
    saveState(); bannerDismissed = false; applyBanner(); closeSheet();
    const activeAdminTab = document.querySelector('#adminTabs .role-tab.active');
    if(activeAdminTab && activeAdminTab.dataset.t==='content') renderAdminTab('content');
    showToast('Poster published to Home for everyone');
  };
  reader.onerror = ()=> showToast('Could not read that image');
  reader.readAsDataURL(file);
}
function removeBanner(){
  state.banner = {image:null, caption:''};
  saveState(); applyBanner(); closeSheet();
  const activeAdminTab = document.querySelector('#adminTabs .role-tab.active');
  if(activeAdminTab && activeAdminTab.dataset.t==='content') renderAdminTab('content');
  showToast('Poster removed from Home');
}
function saveState(){
  try{ localStorage.setItem('alfalah_state', JSON.stringify(state)); }
  catch(e){ console.warn('storage write failed', e); }
}

/* ---------- Splash -> Auth ---------- */
setTimeout(()=>{
  const splash = document.getElementById('splash');
  splash.style.transition = 'opacity .5s ease';
  splash.style.opacity = '0';
  setTimeout(()=>{
    splash.style.display='none';
    document.getElementById('auth').classList.add('active');
  }, 500);
}, 3200);

/* ---------- Auth tabs ---------- */
function switchAuthTab(tab){
  document.getElementById('tabLogin').classList.toggle('active', tab==='login');
  document.getElementById('tabRegister').classList.toggle('active', tab==='register');
  document.getElementById('loginForm').style.display = tab==='login' ? 'block':'none';
  document.getElementById('registerForm').style.display = tab==='register' ? 'block':'none';
}
function setDemoRole(role){
  demoRole = role;
  document.querySelectorAll('.demo-role').forEach(b=>b.classList.toggle('active', b.dataset.role===role));
}

function handleLogin(e){
  e.preventDefault();
  const id = document.getElementById('loginId').value.trim();
  const pass = document.getElementById('loginPass').value;
  const errEl = document.getElementById('loginErr');
  if(!id || pass.length<4){ errEl.style.display='block'; return false; }
  errEl.style.display='none';
  currentUser = {
    name: demoRole==='admin' ? 'Admin' : demoRole==='teacher' ? 'Ustadh Bilal' : (id.split('@')[0]||'Ahmed').replace(/^\w/, c=>c.toUpperCase()),
    email: id.includes('@') ? id : (id+'@alfalah.demo'),
    role: demoRole
  };
  enterApp();
  return false;
}
function handleRegister(e){
  e.preventDefault();
  const p1 = document.getElementById('regPass').value;
  const p2 = document.getElementById('regPass2').value;
  const errEl = document.getElementById('regErr');
  if(p1 !== p2){ errEl.style.display='block'; return false; }
  errEl.style.display='none';
  currentUser = {
    name: document.getElementById('regName').value || 'New Student',
    email: document.getElementById('regEmail').value,
    role: 'student'
  };
  showToast('Registration submitted — awaiting Admin approval (demo)');
  setTimeout(()=>enterApp(), 900);
  return false;
}
function openForgotSheet(){
  openSheet(`
    <h3>Reset Password</h3>
    <div class="field"><label>Registered Email or WhatsApp Number</label><input type="text" placeholder="you@example.com"></div>
    <button class="btn" onclick="closeSheet(); showToast('Reset link sent (demo)')">Send Reset Link</button>
  `);
}

function enterApp(){
  document.getElementById('auth').classList.remove('active');
  document.getElementById('profileName').textContent = currentUser.name;
  document.getElementById('profileEmail').textContent = currentUser.email;
  document.getElementById('profileAvatar').textContent = currentUser.name.charAt(0).toUpperCase();
  document.getElementById('pfName').value = currentUser.name;
  document.getElementById('pfEmail').value = currentUser.email;

  if(currentUser.role==='admin'){
    document.getElementById('adminHome').classList.add('active');
    document.getElementById('studentNav').style.display='none';
    renderAdminTab('overview');
  } else if(currentUser.role==='teacher'){
    document.getElementById('teacherHome').classList.add('active');
    document.getElementById('studentNav').style.display='none';
    renderTeacherTab('classes');
  } else {
    document.getElementById('home').classList.add('active');
    document.getElementById('studentNav').style.display='flex';
    document.getElementById('homeUserName').textContent = currentUser.name.split(' ')[0];
    renderHome();
  }
}

function logout(){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById('studentNav').style.display='none';
  document.getElementById('auth').classList.add('active');
  switchAuthTab('login');
  showToast('Logged out');
}

/* ---------- Navigation (student area) ---------- */
function goHome(){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  if(currentUser.role==='admin'){
    document.getElementById('adminHome').classList.add('active');
  } else if(currentUser.role==='teacher'){
    document.getElementById('teacherHome').classList.add('active');
  } else {
    document.getElementById('home').classList.add('active');
    document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active', b.dataset.p==='home'));
  }
}
function goBackFromProfile(){ goHome(); }
function goTo(page){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById(page).classList.add('active');
  document.querySelectorAll('.nav-btn').forEach(b=>b.classList.toggle('active', b.dataset.p===page));
  const showNav = ['home','courses','classes','videos','material'].includes(page);
  document.getElementById('studentNav').style.display = (currentUser.role==='student') ? (showNav?'flex':'flex') : 'none';
  if(page==='courses') renderCourses();
  if(page==='classes') renderClasses();
  if(page==='videos') renderVideos();
  if(page==='material') renderMaterial();
  if(page==='assignments') renderAssignments();
  if(page==='islamicUpdates') renderIslamicUpdates();
  if(page==='about') applyLogo();
  window.scrollTo(0,0);
}

/* ---------- Render: Home ---------- */
function renderHome(){
  document.getElementById('hadithAr').textContent = state.hadith.ar;
  document.getElementById('hadithTr').textContent = state.hadith.tr;
  document.getElementById('hadithSrc').textContent = '— ' + state.hadith.src;

  const cl = document.getElementById('homeCourseList');
  cl.innerHTML = state.courses.slice(0,2).map(c=>courseCardHTML(c)).join('');

  const kl = document.getElementById('homeClassList');
  kl.innerHTML = state.classes.slice(0,2).map(c=>classCardHTML(c)).join('');
}

function courseCardHTML(c){
  return `<div class="card course-card" onclick="openCourseSheet(${c.id})">
    <div class="course-icon">${svgIcons[c.icon]||svgIcons.book}</div>
    <div class="course-body">
      <h4>${c.title}</h4>
      <p>${c.teacher}</p>
      <div class="meta-row"><span>⏱ ${c.duration}</span><span>👥 ${c.students}</span></div>
      <div class="progress-bar"><div style="width:${c.progress}%"></div></div>
    </div>
  </div>`;
}
function classCardHTML(c){
  return `<div class="card class-card">
    <div class="class-top">
      <h4>${c.course}</h4>
      <span class="pill ${c.status}">${c.status==='live'?'LIVE NOW':'UPCOMING'}</span>
    </div>
    <div class="meta-row"><span>👤 ${c.teacher}</span><span>📅 ${c.date}, ${c.time}</span></div>
    <button class="join-btn" onclick="joinClass('${c.link}')">Join Class</button>
  </div>`;
}
function joinClass(link){
  showToast('Opening meeting link (demo) → ' + link);
}

/* ---------- Render: Courses ---------- */
function renderCourses(){
  const q = (document.getElementById('courseSearch')?.value||'').toLowerCase();
  const list = state.courses.filter(c=>c.title.toLowerCase().includes(q));
  const el = document.getElementById('courseList');
  el.innerHTML = list.length ? list.map(c=>courseCardHTML(c)).join('') : emptyHTML('No courses found');
}
function openCourseSheet(id){
  const c = state.courses.find(x=>x.id===id);
  if(!c) return;
  openSheet(`
    <h3>${c.title}</h3>
    <p style="font-size:12.5px; color:var(--charcoal-400); margin-top:-8px;">${c.desc}</p>
    <div class="meta-row" style="margin:12px 0;">
      <span>👤 ${c.teacher}</span><span>⏱ ${c.duration}</span><span>🕒 ${c.timing}</span><span>👥 ${c.students} students</span>
    </div>
    <div class="progress-bar" style="margin-bottom:16px;"><div style="width:${c.progress}%"></div></div>
    <button class="btn" onclick="closeSheet(); showToast('Enrolled / Joined ${c.title}')">Join Course</button>
  `);
}

/* ---------- Render: Classes ---------- */
let classFilter = 'all';
function filterClasses(f){
  classFilter = f;
  document.querySelectorAll('#classFilterChips .chip').forEach(b=>b.classList.toggle('active', b.dataset.f===f));
  renderClasses();
}
function renderClasses(){
  let list = state.classes;
  if(classFilter!=='all') list = list.filter(c=>c.status===classFilter);
  const el = document.getElementById('classList');
  el.innerHTML = list.length ? list.map(c=>classCardHTML(c)).join('') : emptyHTML('No classes here yet');
}

/* ---------- Render: Videos ---------- */
function renderVideos(){
  const el = document.getElementById('videoList');
  el.innerHTML = state.videos.map(v=>`
    <div class="card video-card" onclick="showToast('Playing: ${v.title.replace(/'/g,"")} (demo)')">
      <div class="thumb"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div>
      <div class="video-body">
        <h4>${v.title}</h4>
        <p>${v.teacher} · ${v.duration}</p>
        <p style="margin-top:3px;">${v.desc}</p>
      </div>
    </div>`).join('');
}

/* ---------- Render: Material ---------- */
const typeIconMeta = {
  Photo:    {emoji:'🖼️', bg:'var(--purple-900)'},
  Audio:    {emoji:'🎵', bg:'var(--purple-900)'},
  Document: {emoji:'📄', bg:'var(--purple-900)'},
  Notes:    {emoji:'📝', bg:'var(--purple-900)'},
  Book:     {emoji:'📘', bg:'var(--purple-900)'},
  PDF:      {emoji:'📕', bg:'var(--purple-900)'},
  Audiobook:{emoji:'🎧', bg:'var(--purple-900)'},
};
function canManageContent(item){
  if(currentUser.role==='admin') return true;
  return !!(item.uploader && item.uploader.email === currentUser.email);
}
function renderMaterial(){
  const el = document.getElementById('materialList');
  if(!state.materials.length){ el.innerHTML = emptyHTML('No books or notes yet — tap Upload to add one'); return; }
  el.innerHTML = state.materials.map(m=>{
    const meta = typeIconMeta[m.type] || typeIconMeta.Book;
    const canManage = canManageContent(m);
    let previewHTML = '';
    if(m.fileData && m.type==='Photo'){
      previewHTML = `<img src="${m.fileData}" alt="${m.title}" style="width:100%;max-height:160px;object-fit:cover;border-radius:12px;margin-top:10px;">`;
    } else if(m.fileData && m.type==='Audio'){
      previewHTML = `<audio controls src="${m.fileData}" style="width:100%;margin-top:10px;"></audio>`;
    }
    const uploaderLine = m.uploader ? `Uploaded by ${m.uploader.name} · ${m.uploader.role.charAt(0).toUpperCase()+m.uploader.role.slice(1)}` : '';
    return `<div class="card">
      <div style="display:flex; align-items:center; gap:12px;">
        <div class="file-icon" style="font-size:18px;">${meta.emoji}</div>
        <div style="flex:1; min-width:0;">
          <h4 style="margin:0 0 2px; font-size:12.5px; font-weight:800;">${m.title}</h4>
          <p style="margin:0; font-size:10.5px; color:var(--charcoal-400);">${m.course} · ${m.type}</p>
          ${uploaderLine ? `<p style="margin:2px 0 0; font-size:9.5px; color:var(--charcoal-400);">${uploaderLine}</p>` : ''}
        </div>
        <div class="row-actions">
          ${m.fileData ? `<a class="mini-btn edit" href="${m.fileData}" download="${(m.fileName||m.title)}" target="_blank" title="Open / Download"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M12 3v12m0 0l-4-4m4 4l4-4M5 21h14"/></svg></a>` : ''}
          ${canManage ? `<button class="mini-btn del" onclick="deleteContent(${m.id})"><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5"><path d="M6 6l12 12M18 6L6 18"/></svg></button>` : ''}
        </div>
      </div>
      ${previewHTML}
    </div>`;
  }).join('');
}
function deleteContent(id){
  const item = state.materials.find(m=>m.id===id);
  if(item && !canManageContent(item)){ showToast('Only the uploader or Admin can remove this'); return; }
  state.materials = state.materials.filter(m=>m.id!==id);
  saveState(); renderMaterial();
  const activeAdminTab = document.querySelector('#adminTabs .role-tab.active');
  if(activeAdminTab && activeAdminTab.dataset.t==='books') renderAdminTab('books');
  showToast('Removed');
}
function openUploadContentSheet(){
  openSheet(`<h3>Upload Content</h3>
    <p style="font-size:11.5px; color:var(--charcoal-400); margin-top:-8px;">Notes, photos, documents or audio — visible to everyone. Admin can manage/remove any upload; you can manage your own.</p>
    <div class="field"><label>Title</label><input type="text" id="ucTitle" placeholder="e.g. My Tajweed Notes"></div>
    <div class="field"><label>Course (optional)</label><select id="ucCourse">${state.courses.map(c=>`<option>${c.title}</option>`).join('')}</select></div>
    <div class="field"><label>Type</label><select id="ucType">
      <option>Notes</option><option>Photo</option><option>Document</option><option>Audio</option><option>Book</option><option>PDF</option>
    </select></div>
    <div class="field"><label>File (optional)</label><input type="file" id="ucFile" accept="image/*,audio/*,.pdf,.doc,.docx,.txt"></div>
    <button class="btn" onclick="submitUploadContent()">Upload</button>`);
}
function submitUploadContent(){
  const title = document.getElementById('ucTitle').value.trim();
  if(!title){ showToast('Enter a title'); return; }
  const course = document.getElementById('ucCourse').value;
  const type = document.getElementById('ucType').value;
  const fileInput = document.getElementById('ucFile');
  const file = fileInput && fileInput.files[0];
  const finish = (fileData, fileName)=>{
    state.materials.unshift({
      id:Date.now(), title, course, type,
      uploader:{name:currentUser.name, role:currentUser.role, email:currentUser.email},
      fileData: fileData||null, fileName: fileName||null
    });
    saveState(); closeSheet(); renderMaterial();
    const activeAdminTab = document.querySelector('#adminTabs .role-tab.active');
    if(activeAdminTab && activeAdminTab.dataset.t==='books') renderAdminTab('books');
    showToast('Uploaded — visible to everyone now');
  };
  if(file){
    const reader = new FileReader();
    reader.onload = e=> finish(e.target.result, file.name);
    reader.onerror = ()=> finish(null, null);
    reader.readAsDataURL(file);
  } else {
    finish(null, null);
  }
}

/* ---------- Render: Assignments ---------- */
function renderAssignments(){
  const el = document.getElementById('assignmentList');
  el.innerHTML = state.assignments.map(a=>{
    const statusMap = {pending:['upcoming','Pending'], submitted:['live','Submitted'], reviewed:['','Reviewed']};
    const [cls,label] = statusMap[a.status]||['',a.status];
    return `<div class="card">
      <div class="class-top"><h4>${a.title}</h4><span class="pill ${cls}">${label.toUpperCase()}</span></div>
      <div class="meta-row"><span>📘 ${a.course}</span><span>📅 Due ${a.due}</span></div>
      ${a.feedback ? `<p style="font-size:11.5px; margin:8px 0 0; color:var(--charcoal-700); background:var(--gold-tint); padding:8px 10px; border-radius:9px;">💬 ${a.feedback}</p>` : ''}
      ${a.status==='pending' ? `<button class="join-btn" onclick="showToast('Assignment submitted')">Submit Assignment</button>` : ''}
    </div>`;
  }).join('');
}

/* ---------- Islamic Updates (Wallpapers / Status / Reels / Posters / Ringtones) ---------- */
const updateCategoryMeta = {
  Wallpaper: {emoji:'🖼️', color:'linear-gradient(150deg,#6B2CAE,#2A0E4A)'},
  Status:    {emoji:'💬', color:'linear-gradient(150deg,#E9AC1F,#8A6708)'},
  Reel:      {emoji:'🎬', color:'linear-gradient(150deg,#2E9E5B,#1B4D30)'},
  Poster:    {emoji:'📌', color:'linear-gradient(150deg,#C4432F,#6B2010)'},
  Ringtone:  {emoji:'🎵', color:'linear-gradient(150deg,#3E1568,#150C22)'},
};
let updateFilter = 'all';
function filterIslamicUpdates(cat){
  updateFilter = cat;
  document.querySelectorAll('#updateFilterChips .chip').forEach(b=>b.classList.toggle('active', b.dataset.f===cat));
  renderIslamicUpdates();
}
function renderIslamicUpdates(){
  document.getElementById('adminUpdateAddBar').style.display = (currentUser.role==='admin') ? 'block' : 'none';
  let list = state.islamicUpdates;
  if(updateFilter!=='all') list = list.filter(u=>u.category===updateFilter);
  const grid = document.getElementById('updateGrid');
  if(!list.length){ grid.style.display='block'; grid.innerHTML = emptyHTML('Nothing here yet'); return; }
  grid.style.display='grid';
  grid.innerHTML = list.map(u=>{
    const meta = updateCategoryMeta[u.category] || updateCategoryMeta.Wallpaper;
    const thumbHTML = u.thumb
      ? `<img src="${u.thumb}" alt="${u.title}" style="width:100%;height:100%;object-fit:cover;">`
      : `<div style="width:100%;height:100%;background:${meta.color};display:flex;align-items:center;justify-content:center;font-size:26px;">${meta.emoji}</div>`;
    return `<div class="card" style="padding:0; overflow:hidden;">
      <div style="width:100%; aspect-ratio:1/1; border-radius:16px 16px 0 0; overflow:hidden;">${thumbHTML}</div>
      <div style="padding:10px;">
        <span class="pill upcoming" style="margin-bottom:6px; display:inline-block;">${u.category.toUpperCase()}</span>
        <h5 style="margin:2px 0 8px; font-size:11.5px; font-weight:800; line-height:1.3;">${u.title}</h5>
        <div style="display:flex; gap:6px;">
          <button class="btn small" style="flex:1; padding:8px 0; font-size:11px;" onclick="showToast('Downloading ${u.title.replace(/'/g,"")} (demo)')">Download</button>
          ${currentUser.role==='admin' ? `<button class="mini-btn del" onclick="deleteIslamicUpdate(${u.id})"><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5"><path d="M6 6l12 12M18 6L6 18"/></svg></button>` : ''}
        </div>
      </div>
    </div>`;
  }).join('');
}
function addIslamicUpdateSheet(){
  openSheet(`<h3>Upload Islamic Update</h3>
    <div class="field"><label>Title</label><input type="text" id="iuTitle" placeholder="e.g. Eid Mubarak Wallpaper"></div>
    <div class="field"><label>Category</label><select id="iuCategory">
      <option>Wallpaper</option><option>Status</option><option>Reel</option><option>Poster</option><option>Ringtone</option>
    </select></div>
    <div class="field"><label>Thumbnail / File (optional)</label><input type="file" id="iuFile" accept="image/*"></div>
    <button class="btn" onclick="addIslamicUpdate()">Upload</button>
    <p style="font-size:11px; color:var(--charcoal-400); margin-top:10px;">Visible instantly to every Student and Teacher. Only Admin can upload or delete.</p>`);
}
function addIslamicUpdate(){
  const title = document.getElementById('iuTitle').value.trim();
  const category = document.getElementById('iuCategory').value;
  if(!title){ showToast('Enter a title'); return; }
  const fileInput = document.getElementById('iuFile');
  const file = fileInput && fileInput.files[0];
  const finish = (thumb)=>{
    state.islamicUpdates.unshift({id:Date.now(), title, category, thumb: thumb||null, link:''});
    saveState(); closeSheet(); updateFilter='all';
    document.querySelectorAll('#updateFilterChips .chip').forEach(b=>b.classList.toggle('active', b.dataset.f==='all'));
    renderIslamicUpdates(); showToast('Uploaded — visible to everyone now');
  };
  if(file){
    const reader = new FileReader();
    reader.onload = e=> finish(e.target.result);
    reader.onerror = ()=> finish(null);
    reader.readAsDataURL(file);
  } else {
    finish(null);
  }
}
function deleteIslamicUpdate(id){
  state.islamicUpdates = state.islamicUpdates.filter(u=>u.id!==id);
  saveState(); renderIslamicUpdates(); showToast('Removed');
}

function emptyHTML(msg){
  return `<div class="empty"><svg viewBox="0 0 24 24" fill="none" stroke-width="1.5"><circle cx="12" cy="12" r="9"/></svg><p>${msg}</p></div>`;
}

/* ---------- Sheets / Toasts ---------- */
function openSheet(html){
  document.getElementById('sheetContent').innerHTML = html;
  document.getElementById('sheetOverlay').classList.add('open');
}
function closeSheet(){ document.getElementById('sheetOverlay').classList.remove('open'); }
function showToast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(()=>t.classList.remove('show'), 2400);
}
function openNotifSheet(){
  openSheet(`<h3>Notifications</h3>
    <div class="list-row"><div class="info"><h5>New class scheduled</h5><p>Hifz-ul-Quran class moved to 4:00 PM today</p></div></div>
    <div class="list-row"><div class="info"><h5>Assignment reviewed</h5><p>Your Duas homework has feedback from Ustadha Ayesha</p></div></div>
    <div class="list-row"><div class="info"><h5>Announcement</h5><p>Institute will be closed on Eid holidays</p></div></div>`);
}
function openProgressSheet(){
  const rows = state.courses.filter(c=>c.progress>0).map(c=>`
    <div class="list-row"><div class="info"><h5>${c.title}</h5><p>${c.progress}% complete</p></div></div>`).join('');
  openSheet(`<h3>My Progress</h3>${rows}`);
}

/* ================= ADMIN PANEL ================= */
function setAdminTab(t){
  document.querySelectorAll('#adminTabs .role-tab').forEach(b=>b.classList.toggle('active', b.dataset.t===t));
  renderAdminTab(t);
}
function renderAdminTab(t){
  const el = document.getElementById('adminBody');
  if(t==='overview'){
    el.innerHTML = `
      <div class="stat-grid">
        <div class="stat-card"><div class="num">${state.students.length}</div><div class="lbl">Total Students</div></div>
        <div class="stat-card"><div class="num">${state.teachers.length}</div><div class="lbl">Active Teachers</div></div>
        <div class="stat-card"><div class="num">${state.courses.length}</div><div class="lbl">Courses</div></div>
        <div class="stat-card"><div class="num">${state.classes.length}</div><div class="lbl">Classes Scheduled</div></div>
      </div>
      <div class="section-title"><h3>Pending Approvals</h3></div>
      <div class="card">
        ${state.students.filter(s=>s.status==='pending').map(s=>`
          <div class="list-row">
            <div class="info"><h5>${s.name}</h5><p>${s.email} · ${s.city}</p></div>
            <div class="row-actions">
              <button class="mini-btn edit" onclick="approveStudent(${s.id})"><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5"><path d="M5 12l5 5L19 7"/></svg></button>
              <button class="mini-btn del" onclick="removeStudent(${s.id})"><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
            </div>
          </div>`).join('') || '<p style="font-size:12px;color:var(--charcoal-400);padding:6px 0;">No pending approvals</p>'}
      </div>
      <div class="section-title"><h3>Quick Actions</h3></div>
      <div style="display:flex; gap:10px; flex-wrap:wrap;">
        <button class="btn small" onclick="setAdminTab('hadith')">+ Add Hadith</button>
        <button class="btn small ghost" onclick="setAdminTab('courses')">+ Add Course</button>
        <button class="btn small ghost" onclick="openAnnouncementSheet()">📢 Announcement</button>
      </div>`;
  }
  else if(t==='users'){
    el.innerHTML = `<div class="section-title"><h3>Students (${state.students.length})</h3></div>
      <div class="card">${state.students.map(s=>`
        <div class="list-row">
          <span class="status-dot ${s.status}"></span>
          <div class="info"><h5>${s.name}</h5><p>${s.email} · ${s.city}</p></div>
          <div class="row-actions">
            <button class="mini-btn edit" onclick="editStudent(${s.id})"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg></button>
            <button class="mini-btn del" onclick="removeStudent(${s.id})"><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
          </div>
        </div>`).join('')}</div>`;
  }
  else if(t==='teachers'){
    el.innerHTML = `<div class="section-title"><h3>Teachers (${state.teachers.length})</h3><a onclick="addTeacherSheet()">+ Add</a></div>
      <div class="card">${state.teachers.map(tc=>`
        <div class="list-row">
          <span class="status-dot approved"></span>
          <div class="info"><h5>${tc.name}</h5><p>${tc.subject}</p></div>
          <div class="row-actions">
            <button class="mini-btn edit" onclick="showToast('Editing ${tc.name}')"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg></button>
            <button class="mini-btn del" onclick="removeTeacher(${tc.id})"><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
          </div>
        </div>`).join('')}</div>`;
  }
  else if(t==='courses'){
    el.innerHTML = `<div class="section-title"><h3>Courses (${state.courses.length})</h3><a onclick="showToast('Add course form (demo)')">+ Add</a></div>
      <div class="card">${state.courses.map(c=>`
        <div class="list-row">
          <div class="info"><h5>${c.title}</h5><p>${c.teacher} · ${c.students} students</p></div>
          <div class="row-actions">
            <button class="mini-btn edit" onclick="showToast('Editing ${c.title.replace(/'/g,"")}')"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg></button>
            <button class="mini-btn del" onclick="showToast('Delete requires confirmation (demo)')"><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
          </div>
        </div>`).join('')}</div>`;
  }
  else if(t==='books'){
    el.innerHTML = `<div class="section-title"><h3>Books &amp; Content (${state.materials.length})</h3><a onclick="adminAddBookSheet()">+ Add</a></div>
      <p style="font-size:11.5px; color:var(--charcoal-400); margin:-6px 0 12px;">No limit. Includes books plus notes/photos/documents/audio uploaded by students &amp; teachers — Admin can remove any of it.</p>
      <div class="card">${state.materials.map(m=>`
        <div class="list-row">
          <div class="file-icon" style="width:36px;height:36px;">${svgIcons.book}</div>
          <div class="info"><h5>${m.title}</h5><p>${m.course} · ${m.type}${m.uploader ? ' · by '+m.uploader.name+' ('+m.uploader.role+')' : ''}</p></div>
          <div class="row-actions">
            <button class="mini-btn edit" onclick="showToast('Editing ${m.title.replace(/'/g,"")}')"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg></button>
            <button class="mini-btn del" onclick="deleteContent(${m.id})"><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
          </div>
        </div>`).join('') || '<p style="font-size:12px;color:var(--charcoal-400);padding:6px 0;">No books yet — add your first one</p>'}</div>`;
  }
  else if(t==='hadith'){
    el.innerHTML = `<div class="section-title"><h3>Daily Hadith</h3></div>
      <div class="card">
        <div class="field"><label>Arabic Text</label><textarea class="field-textarea ar" id="adHadithAr">${state.hadith.ar}</textarea></div>
        <div class="field"><label>Translation</label><textarea class="field-textarea" id="adHadithTr">${state.hadith.tr}</textarea></div>
        <div class="field"><label>Reference / Source</label><input type="text" id="adHadithSrc" value="${state.hadith.src}"></div>
        <button class="btn" onclick="saveHadith()">Save Hadith</button>
      </div>`;
  }
  else if(t==='content'){
    el.innerHTML = `<div class="section-title"><h3>App Content</h3></div>
      <div class="card">
        <div class="list-row">
          <img class="app-logo-img" src="" alt="Current logo" style="width:38px;height:38px;border-radius:12px;object-fit:cover;flex-shrink:0;">
          <div class="info"><h5>App Logo</h5><p>Shown on splash, login and every dashboard</p></div>
          <button class="btn small ghost" onclick="changeLogoSheet()">Change</button>
        </div>
        <div class="list-row">
          ${state.banner && state.banner.image ? `<img src="${state.banner.image}" alt="Current poster" style="width:38px;height:38px;border-radius:12px;object-fit:cover;flex-shrink:0;">` : `<div class="file-icon" style="width:38px;height:38px;">📢</div>`}
          <div class="info"><h5>Home Poster / Announcement</h5><p>Reel-size poster shown on Home for everyone</p></div>
          <button class="btn small ghost" onclick="changeBannerSheet()">${state.banner && state.banner.image ? 'Change' : 'Upload'}</button>
        </div>
        <div class="list-row"><div class="info"><h5>Testimonials</h5><p>Manage homepage testimonials</p></div><button class="btn small ghost" onclick="showToast('Manage testimonials (demo)')">Manage</button></div>
        <div class="list-row"><div class="info"><h5>FAQ</h5><p>Frequently asked questions</p></div><button class="btn small ghost" onclick="showToast('Manage FAQ (demo)')">Manage</button></div>
        <div class="list-row"><div class="info"><h5>About Section</h5><p>Institute description</p></div><button class="btn small ghost" onclick="showToast('Edit About (demo)')">Edit</button></div>
        <div class="list-row"><div class="info"><h5>Contact Info</h5><p>Phone, email, address</p></div><button class="btn small ghost" onclick="showToast('Edit contact info (demo)')">Edit</button></div>
        <div class="list-row"><div class="info"><h5>WhatsApp / Instagram / Telegram</h5><p>Social links</p></div><button class="btn small ghost" onclick="showToast('Edit social links (demo)')">Edit</button></div>
        <div class="list-row"><div class="info"><h5>Class Meeting Links</h5><p>Update Zoom / Google Meet links</p></div><button class="btn small ghost" onclick="setAdminTab('courses')">Manage</button></div>
      </div>`;
    applyLogo();
  }
}
function approveStudent(id){
  const s = state.students.find(x=>x.id===id);
  if(s){ s.status='approved'; saveState(); renderAdminTab('overview'); showToast(s.name+' approved'); }
}
function removeStudent(id){
  state.students = state.students.filter(x=>x.id!==id);
  saveState(); renderAdminTab(document.querySelector('#adminTabs .role-tab.active').dataset.t);
  showToast('Student removed');
}
function editStudent(id){ showToast('Edit student form (demo)'); }
function removeTeacher(id){
  state.teachers = state.teachers.filter(x=>x.id!==id);
  saveState(); renderAdminTab('teachers'); showToast('Teacher removed');
}
function addTeacherSheet(){
  openSheet(`<h3>Add Teacher</h3>
    <div class="field"><label>Full Name</label><input type="text" id="ntName" placeholder="Ustadh name"></div>
    <div class="field"><label>Subject</label><input type="text" id="ntSubject" placeholder="e.g. Tajweed"></div>
    <button class="btn" onclick="addTeacher()">Create Teacher Account</button>`);
}
function addTeacher(){
  const name = document.getElementById('ntName').value.trim();
  const subject = document.getElementById('ntSubject').value.trim();
  if(!name) return;
  state.teachers.push({id:Date.now(), name, subject:subject||'General', status:'active'});
  saveState(); closeSheet(); renderAdminTab('teachers'); showToast('Teacher account created');
}
function changeLogoSheet(){
  openSheet(`<h3>Change App Logo</h3>
    <p style="font-size:11.5px; color:var(--charcoal-400); margin-top:-8px;">Upload a square image. It will replace the logo on the splash screen, login page and every dashboard.</p>
    <div class="field"><label>Logo Image</label><input type="file" id="logoFile" accept="image/*"></div>
    <button class="btn" onclick="applyNewLogo()">Save Logo</button>`);
}
function applyNewLogo(){
  const fileInput = document.getElementById('logoFile');
  const file = fileInput && fileInput.files[0];
  if(!file){ showToast('Choose an image first'); return; }
  const reader = new FileReader();
  reader.onload = (e)=>{
    state.logo = e.target.result;
    saveState();
    applyLogo();
    closeSheet();
    showToast('Logo updated across the app');
  };
  reader.onerror = ()=> showToast('Could not read that image');
  reader.readAsDataURL(file);
}
function saveHadith(){
  state.hadith = {
    ar: document.getElementById('adHadithAr').value,
    tr: document.getElementById('adHadithTr').value,
    src: document.getElementById('adHadithSrc').value,
  };
  saveState(); showToast('Daily Hadith updated');
}
function openAnnouncementSheet(){
  openSheet(`<h3>Publish Announcement</h3>
    <div class="field"><label>Title</label><input type="text" id="anTitle" placeholder="Announcement title"></div>
    <div class="field"><label>Message</label><textarea class="field-textarea" id="anBody" placeholder="Write your announcement..."></textarea></div>
    <button class="btn" onclick="closeSheet(); showToast('Announcement published')">Publish</button>`);
}

/* ================= TEACHER PANEL ================= */
function setTeacherTab(t){
  document.querySelectorAll('#teacherTabs .role-tab').forEach(b=>b.classList.toggle('active', b.dataset.t===t));
  renderTeacherTab(t);
}
function renderTeacherTab(t){
  const el = document.getElementById('teacherBody');
  if(t==='classes'){
    el.innerHTML = `<div class="section-title"><h3>Assigned Classes</h3></div>` +
      state.classes.slice(0,3).map(c=>`
        <div class="card class-card">
          <div class="class-top"><h4>${c.course}</h4><span class="pill ${c.status}">${c.status==='live'?'LIVE':'UPCOMING'}</span></div>
          <div class="meta-row"><span>📅 ${c.date}, ${c.time}</span></div>
          <div style="display:flex; gap:8px; margin-top:10px;">
            <button class="join-btn" style="margin-top:0;" onclick="joinClass('${c.link}')">Join</button>
            <button class="btn ghost small" onclick="showToast('Link change requires Admin permission')">Change Link</button>
          </div>
        </div>`).join('');
  }
  else if(t==='material'){
    el.innerHTML = `<div class="section-title"><h3>Books &amp; Content</h3><a onclick="openUploadContentSheet()">+ Upload</a></div>
      <p style="font-size:11px; color:var(--charcoal-400); margin:-8px 0 12px;">You can manage items you uploaded. Admin can manage all of it.</p>` +
      (state.materials.map(m=>{
        const canManage = canManageContent(m);
        return `<div class="card material-card">
          <div class="file-icon">${(typeIconMeta[m.type]||typeIconMeta.Book).emoji}</div>
          <div style="flex:1;"><h4 style="margin:0 0 2px; font-size:12.5px; font-weight:800;">${m.title}</h4><p style="margin:0; font-size:10.5px; color:var(--charcoal-400);">${m.course} · ${m.type}${m.uploader ? ' · by '+m.uploader.name : ''}</p></div>
          <div class="row-actions">
            ${m.fileData ? `<a class="mini-btn edit" href="${m.fileData}" download="${(m.fileName||m.title)}" target="_blank"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M12 3v12m0 0l-4-4m4 4l4-4M5 21h14"/></svg></a>` : ''}
            ${canManage ? `<button class="mini-btn del" onclick="deleteContent(${m.id}); setTeacherTab('material')"><svg viewBox="0 0 24 24" fill="none" stroke-width="2.5"><path d="M6 6l12 12M18 6L6 18"/></svg></button>` : ''}
          </div>
        </div>`;
      }).join('') || '<p style="font-size:12px;color:var(--charcoal-400);padding:6px 0;">Nothing uploaded yet</p>');
  }
  else if(t==='assignments'){
    el.innerHTML = `<div class="section-title"><h3>Student Submissions</h3><a onclick="createAssignmentSheet()">+ New</a></div>` +
      state.assignments.map(a=>`
        <div class="card">
          <div class="class-top"><h4>${a.title}</h4><span class="pill ${a.status==='reviewed'?'':'upcoming'}">${a.status.toUpperCase()}</span></div>
          <div class="meta-row"><span>📘 ${a.course}</span><span>📅 Due ${a.due}</span></div>
          ${a.status!=='reviewed' ? `<button class="join-btn" onclick="giveFeedbackSheet('${a.title.replace(/'/g,"")}')">Review &amp; Give Feedback</button>` : `<p style="font-size:11.5px; margin:8px 0 0; color:var(--charcoal-700); background:var(--gold-tint); padding:8px 10px; border-radius:9px;">💬 ${a.feedback}</p>`}
        </div>`).join('');
  }
  else if(t==='videos'){
    el.innerHTML = `<div class="section-title"><h3>My Videos</h3><a onclick="uploadVideoSheet()">+ Upload</a></div>` +
      state.videos.map(v=>`
        <div class="card video-card">
          <div class="thumb"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div>
          <div class="video-body"><h4>${v.title}</h4><p>${v.duration}</p></div>
          <div class="row-actions" style="align-items:center;">
            <button class="mini-btn edit" onclick="showToast('Editing video (demo)')"><svg viewBox="0 0 24 24" fill="none" stroke-width="2"><path d="M12 20h9M16.5 3.5a2.1 2.1 0 013 3L7 19l-4 1 1-4z"/></svg></button>
          </div>
        </div>`).join('');
  }
}
function adminAddBookSheet(){
  openSheet(`<h3>Add Book</h3>
    <p style="font-size:11.5px; color:var(--charcoal-400); margin-top:-8px;">Unlimited books can be added — no cap.</p>
    <div class="field"><label>Book Title</label><input type="text" id="abTitle" placeholder="e.g. Bahishti Zewar"></div>
    <div class="field"><label>Related Course</label><select id="abCourse">${state.courses.map(c=>`<option>${c.title}</option>`).join('')}</select></div>
    <div class="field"><label>Type</label><select id="abType"><option>Book</option><option>PDF</option><option>Notes</option><option>Audiobook</option></select></div>
    <button class="btn" onclick="addBookFromAdmin()">Add Book</button>`);
}
function addBookFromAdmin(){
  const title = document.getElementById('abTitle').value.trim();
  if(!title){ showToast('Enter a book title'); return; }
  state.materials.unshift({id:Date.now(), title, course:document.getElementById('abCourse').value, type:document.getElementById('abType').value, uploader:{name:currentUser.name, role:'admin', email:currentUser.email}, fileData:null});
  saveState(); closeSheet(); renderAdminTab('books'); showToast('Book added — visible to all students & teachers');
}
function deleteBook(id){ deleteContent(id); }
function createAssignmentSheet(){
  openSheet(`<h3>Create Assignment</h3>
    <div class="field"><label>Title</label><input type="text" id="caTitle" placeholder="Assignment title"></div>
    <div class="field"><label>Course</label><select id="caCourse">${state.courses.map(c=>`<option>${c.title}</option>`).join('')}</select></div>
    <div class="field"><label>Description</label><textarea class="field-textarea" id="caDesc" placeholder="Instructions..."></textarea></div>
    <div class="field"><label>Submission Date</label><input type="date" id="caDate"></div>
    <button class="btn" onclick="closeSheet(); showToast('Assignment created and shared with students')">Create Assignment</button>`);
}
function giveFeedbackSheet(title){
  openSheet(`<h3>Review: ${title}</h3>
    <div class="field"><label>Feedback</label><textarea class="field-textarea" placeholder="Write feedback for the student..."></textarea></div>
    <button class="btn" onclick="closeSheet(); showToast('Feedback sent to student')">Send Feedback</button>`);
}
function uploadVideoSheet(){
  openSheet(`<h3>Upload Video</h3>
    <div class="field"><label>Title</label><input type="text" id="uvTitle" placeholder="Video title"></div>
    <div class="field"><label>Description</label><textarea class="field-textarea" id="uvDesc" placeholder="Short description"></textarea></div>
    <div class="field"><label>Video URL</label><input type="text" placeholder="https://..."></div>
    <button class="btn" onclick="uploadVideo()">Upload Video</button>`);
}
function uploadVideo(){
  const title = document.getElementById('uvTitle').value.trim();
  if(!title) return;
  state.videos.unshift({id:Date.now(), title, teacher:currentUser.name, desc:document.getElementById('uvDesc').value||'', duration:'0:00'});
  saveState(); closeSheet(); renderTeacherTab('videos'); showToast('Video uploaded');
}
